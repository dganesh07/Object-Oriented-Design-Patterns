import java.awt.Graphics;

public interface Animal {

	void draw(Graphics g, ImagePanel imagePanel);;
}
