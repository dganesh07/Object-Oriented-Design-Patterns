package com.animalfarm.strategy;

public class Behavior2 implements FeedingBehavior {

	@Override
	public String getFeedingBehavior() {
		return "Herbivore";
	}
}
