package com.animalfarm.strategy;

public class Behavior1 implements FeedingBehavior {

	@Override
	public String getFeedingBehavior() {
		return "Omnivore";
	}
}
