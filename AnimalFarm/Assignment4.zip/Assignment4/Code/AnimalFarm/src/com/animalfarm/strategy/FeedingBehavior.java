package com.animalfarm.strategy;

public interface FeedingBehavior {
	public String getFeedingBehavior();
}
