package com.animalfarm.main;

public class AccessClass {
	public static void main(String args[]) {
		
		HumanSocietyCenter humanCenter = new HumanSocietyCenter();
		humanCenter.start();
	}
	
}
