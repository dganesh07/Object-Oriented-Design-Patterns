package com.animalfarm.strategy;

public class Behavior3 implements FeedingBehavior {

	@Override
	public String getFeedingBehavior() {
		return "Carnivore";
	}
}
